
public interface Hibrida {
	
	public int getPotenciaMotorElectrico();
}
